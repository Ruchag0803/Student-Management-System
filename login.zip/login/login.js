

// const mysql = require("mysql");
// const express = require("express");
// const session = require("express-session");
// const path = require("path");
// const bodyParser = require("body-parser");
// const encoder = bodyParser.urlencoded();

// const app = express();
// const connection = mysql.createConnection({
//     host: "localhost",
//     user: "root",
//     password: "1234567890",
//     database: "nodejs"
// });

// app.use(express.static(path.join(__dirname, "public")));

// // Configure session
// app.use(session({
//     secret: "your-secret-key",
//     resave: false,
//     saveUninitialized: true
// }));

// connection.connect(function (error) {
//     if (error) throw error;
//     else console.log("Connection established ");
// });

// app.get("/", function (req, res) {
//     res.sendFile(__dirname + "/login.html");
// });

// app.post("/", encoder, function (req, res) {
//     var username = req.body.username;
//     var password = req.body.password;
   

//     connection.query("SELECT * FROM userlogin WHERE username=? AND password=?", [username, password], function (error, results, fields) {

//         if (error) {
//             throw error;
//         }
//         if (results && results.length > 0) {
//             // Check if the username belongs to a student or teacher based on the email domain
//             if (username.endsWith("@mgm.ac.in")) {
//                 // Student login
//                 req.session.username = username;
//                 res.redirect("/dashboard");
//             } else if (username.endsWith("@mgmfac.ac.in")) {
//                 // Teacher login
//                 res.redirect("/teacher_login");
//             } else {
//                 // Redirect to a generic page if the username domain is not recognized
//                 res.redirect("/");
//             }
//         } else {
//             res.redirect("/");
//         }
//     });
// });

// app.get("/dashboard", function (req, res) {
//     var username = req.session.username;
//     if (username) {
//         // res.sendFile(__dirname + "/dashboard.html");
//         res.render("dashboard", { username: username }); 
//     } else {
//         res.redirect("/");
//     }
// });

// app.get("/teacher_login", function (req, res) {
//     res.sendFile(__dirname + "/teacher_login.html");
// });

// app.listen(4200, () => {
//     console.log("Server is listening on port 4200");
// });


const mysql = require("mysql");
const express = require("express");
const session = require("express-session");
const path = require("path");
const bodyParser = require("body-parser");
const encoder = bodyParser.urlencoded();

const app = express();
const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "1234567890",
    database: "nodejs"
});

app.use(express.static(path.join(__dirname, "public")));

const session = require("express-session");
// Configure session
app.use(session({
    secret: "your-secret-key",
    resave: false,
    saveUninitialized: true
}));

connection.connect(function (error) {
    if (error) throw error;
    else console.log("Connection established ");
});

app.get("/", function (req, res) {
    res.sendFile(__dirname + "/login.html");
});

app.post("/", encoder, function (req, res) {
    var username = req.body.username;
    var password = req.body.password;

    connection.query("SELECT * FROM userlogin WHERE username=? AND password=?", [username, password], function (error, results, fields) {

        if (error) {
            throw error;
        }
        if (results && results.length > 0) {
            // Check if the username belongs to a student or teacher based on the email domain
            if (username.endsWith("@mgm.ac.in")) {
                // Student login
                req.session.username = username;
                res.redirect("/std_dash");
            } else if (username.endsWith("@mgmfac.ac.in")) {
                // Teacher login
                res.redirect("/teacher_login");
            } else {
                // Redirect to a generic page if the username domain is not recognized
                res.redirect("/");
            }
        } else {
            res.redirect("/");
        }
    });
});

app.get("/std_dash", function (req, res) {
    const username = req.session.username;

    if (!username) {
        res.status(400).send("username not provided");
    } else {
        // You can place the logic for rendering the dashboard here
        res.render("dashboard", { username: username, attendanceData: [] }); // Assuming an empty attendanceData for now
    }
});


app.get("/teacher_login", function (req, res) {
    res.sendFile(__dirname + "/teacher_login.html");
});

app.listen(4200, () => {
    console.log("Server is listening on port 4200");
});
