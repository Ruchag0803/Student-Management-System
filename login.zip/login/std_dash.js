// const mysql = require("mysql");
// const express = require("express");
// const path = require("path");  
// const bodyParser = require("body-parser");
// const encoder = bodyParser.urlencoded();
// const session = require("express-session");
// const ejs = require("ejs");

// const app = express();

// app.set("view engine", "ejs");

// const connection = mysql.createConnection(
//     {
//         host: "localhost",
//         user: "root",
//         password: "1234567890",
//         database: "nodejs"
//     }
// );

// app.use(session({
//     secret: "your-secret-key",
//     resave: false,
//     saveUninitialized: true
// }));


// connection.connect(function(error)
// {
//     if(error) throw error
//     else console.log("Connection eastiblished ")
// })
// app.use(express.static(path.join(__dirname, "public")));



// app.get("/std_login",function(req,res)
// {
//     const username=req.query.username;

//     if(!username)
//     {
//         res.status(400).send("username not provided");
//     }
// else{
//   connection.query("select u.username,s1.sub_name,s1.attendance,s1.percentage FROM userlogin as u, subject1 as s1 WHERE u.username=s1.username and u.username= ?;", [username], 
//   function(error, results, fields) {

//         if (error) {
//             console.error("Error executing query: " + error.stack);
//         res.status(500).send("Internal Server Error");
//         return;
//         }
//         if(results && results.length >0){
//         res.render("dashboard.html", { username: username, attendanceData: results });
//         }

//         else{
//             res.redirect("/no-attendance");
//         }
//     });
// }
// });
// const port = 4200;
// app.listen(port, () => {
//     console.log(`Server is listening on port ${port}`);
// });


const mysql = require("mysql");
const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const session = require("express-session");
const ejs = require("ejs");

const app = express();

app.set("view engine", "ejs");

const connection = mysql.createConnection(
    {
        host: "localhost",
        user: "root",
        password: "1234567890",
        database: "nodejs"
    }
);

app.use(session({
    secret: "your-secret-key",
    resave: false,
    saveUninitialized: true
}));

connection.connect(function (error) {
    if (error) throw error
    else console.log("Connection established ")
})
app.use(express.static(path.join(__dirname, "public")));

app.get("/std_dash", function (req, res) {
    const username = req.session.username;

    if (!username) {
        res.status(400).send("username not provided");
    }
    else {
        connection.query("select u.username, s1.sub_name, s1.attendance, s1.percentage FROM userlogin as u, subject1 as s1 WHERE u.username=s1.username and u.username= ?;", [username],
            function (error, results, fields) {

                if (error) {
                    console.error("Error executing query: " + error.stack);
                    res.status(500).send("Internal Server Error");
                    return;
                }
                if (results && results.length > 0) {
                    res.render("dashboard", { username: username, attendanceData: results });
                }

                else {
                    res.redirect("/no-attendance");
                }
            });
    }
});

const port = 4200;
app.listen(port, () => {
    console.log(`Server is listening on port ${port}`);
});
